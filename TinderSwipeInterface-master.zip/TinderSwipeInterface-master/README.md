# TinderSwipeInterface
We will create Tinder Stack and Swiping animation using Swift.

![](Tinder.gif)
